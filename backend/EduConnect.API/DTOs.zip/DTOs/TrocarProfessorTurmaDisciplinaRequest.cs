﻿namespace EduConnect.API.DTOs
{
    public class TrocarProfessorTurmaDisciplinaRequest
    {
        public int ProfessorId { get; set; }
    }
}
