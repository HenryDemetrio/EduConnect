﻿namespace EduConnect.API.DTOs
{
    public class UpdateTurmaDisciplinaProfessorRequest
    {
        public int ProfessorId { get; set; }
    }
}
