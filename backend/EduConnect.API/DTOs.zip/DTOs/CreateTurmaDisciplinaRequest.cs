﻿namespace EduConnect.API.DTOs
{
    public class CreateTurmaDisciplinaRequest
    {
        public int DisciplinaId { get; set; }
        public int ProfessorId { get; set; }
    }
}
