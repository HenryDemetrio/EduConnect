﻿namespace EduConnect.API.DTOs
{
    public class MatricularAlunoRequest
    {
        public int AlunoId { get; set; }
        public int TurmaId { get; set; }
    }
}
