﻿namespace EduConnect.API.DTOs
{
    public class UpdateProfessorRequest
    {
        public string Nome { get; set; } = null!;
        public string Registro { get; set; } = null!;
        public string EmailContato { get; set; } = null!;

    }
}
